from operator import itemgetter
import sys


current_date = None
mini_temp = 10000
maxi_temp = -10000


for l in sys.stdin:
	l = l.strip()
	date, temp = l.split("\t")
	
	try:
		temp = float(temp)
	except ValueError:
		continue

	if maxi_temp < temp:
		maxi_temp = temp
	if mini_temp > temp:
		mini_temp = temp

else:
	print("max-temp : ", maxi_temp,"\tmini_temp : ",mini_temp)
